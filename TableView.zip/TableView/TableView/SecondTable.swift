//
//  SecondTable.swift
//  TableView
//
//  Created by Jared Davidson on 1/16/15.
//  Copyright (c) 2015 Archetapp. All rights reserved.
//

import Foundation


struct SecondTable {
    var SecondTitle : [String]
}